package configurationSpring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import javaDAOs.MariaDBConnection;

@Configuration
@ComponentScan("javaDAOs")
public class RootAppConfig {
	
	@Bean
	public MariaDBConnection getDatabaseConnection() {
		
		return new MariaDBConnection();
		
	}

}
