package controllersSpring;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javaDAOs.BookDAO;
import javaModels.Book;

@Controller
public class BookController {
	
	@Autowired
	BookDAO b_dao;
	
	//Path that will be displayed in the URL to call this method
	//Default- Meaning that it will run first when you run the app
	@RequestMapping("/")
	public String showHelloPage(Model model) throws SQLException {
		
		List<Book> allBooks = b_dao.getAllBooks();
		
		model.addAttribute("allBooks",allBooks);
		
		model.addAttribute("book",new Book());
		
		//Name of JSP that will be called
		return "bookPage";
		
	}
	
	@RequestMapping("/addBook")
	public String addBook(@Valid @ModelAttribute("book") Book book,BindingResult result,Model model) throws SQLException, ClassNotFoundException, IOException {
		
		if(result.hasErrors()) {
			
			System.out.println("Invalid input");
			List<Book> allBooks = b_dao.getAllBooks();
			
			model.addAttribute("allBooks",allBooks);
			
			
			return "bookPage";
		}
				
		Integer bookId = b_dao.registerBook(book);
		
		if(bookId==-1) {
			System.out.println("Unable to insert bok");
			List<Book> allBooks = b_dao.getAllBooks();
			
			model.addAttribute("allBooks",allBooks);
			model.addAttribute("errorMessage","Add book failed");
			return "bookPage";
		}
		
		System.out.println("Redicting with updated page");
		return "redirect:/";
		
	}
	
	@RequestMapping("/removeBook/{bookId}")
	public String removeBook(@PathVariable Integer bookId) throws IOException, SQLException {
		
		Boolean b = b_dao.removeBookById(bookId);
		
		return "forward:/";
		
	}
	
	

	

}
