package javaDAOs;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javaDAOs.MariaDBConnection;

import javaModels.Book;


@Repository
public class BookDAO {
	
	@Autowired
	MariaDBConnection mysql;
	
	//Returns an ArrayList filled with Brands objects from database(Retrieve method)
	public ArrayList<Book> getAllBooks() throws SQLException {
		// Declare variables
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		Book u = null;
		ArrayList<Book> brandList = null;

		// Assign query string to a variable
		String qString = "select * from book";

		// Create MySqlConnection class instance
		

		// Begin try/catch block to query the database
		try
		{
			// Connect to database
			conn = mysql.getConnection();
			// If the connection fails the application won't make it to this point
			
			// Create Statement instance/object
			stmt = conn.createStatement();
		
			// Run query and assign to the ResultSet instance
			rs = stmt.executeQuery(qString);
			//Create list to hold Brands objects
			brandList = new ArrayList<Book>();
			// Read the ResultSet instance
			while (rs.next()) {
				// Each iteration creates a new Brand
				u = new Book();
				// Assign columns/fields to related fields in the Brand object
				// 1,2 and 3 represent column numbers/positions
				u.setBookId(rs.getInt(1));
				u.setTitle(rs.getString(2));
				u.setAuthor(rs.getString(3));
				// Add the Brand to the list
				brandList.add(u);
				// Repeat until rs.next() returns false (i.e., end of ResultSet)
			}
		}
		catch (ClassNotFoundException | IOException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
			e.getStackTrace();
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return brandList;
	} // End of getAllBrands method	

	public Integer registerBook(Book inputBrand) throws SQLException, ClassNotFoundException, IOException {
		// Declare variables
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		// Assign insert statement string to variable
		String insertString = "insert into book (title, author) values (?,?)";
		
	    int ID = inputBrand.getBookId();
	    String[] COL = {"book_id"};
	    
	    
	    
	    try
	    {
	        conn = mysql.getConnection();
	        stmt = conn.prepareStatement(insertString, COL);
	        
	        
	        stmt.setString(1, inputBrand.getTitle());
	        stmt.setString(2, inputBrand.getAuthor());
	        
	        stmt.executeUpdate();
	        
	        rs = stmt.getGeneratedKeys();
	        if(rs != null && rs.next()) {
	            ID = rs.getInt(1);
	        }
	        System.out.println(ID);
	    }
	    catch (SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
		}
		finally
		{
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
	    
		return ID;
	} // End of registerBrand() method
	
	//Deletes a Brands object from the DB through an ID provided
	public Boolean removeBookById(int bookId) throws IOException, SQLException {
		// Declare variables
		Connection conn = null;
		PreparedStatement stmt = null;
		Integer updateResult = null;
		
		// Assign delete string to variable
		String deleteString = "delete from book where book_id = ?";
		
		// Create MySqlConnection class instance
		
		// Begin try/catch block to query the database
		try
		{
			// Connect to database and assign query string to PreparedStatement object
			conn = mysql.getConnection();
			stmt = conn.prepareStatement(deleteString);
			
			// Set query parameters (?)
			stmt.setInt(1, bookId);
			// Run query and assign to ResultSet
			updateResult = stmt.executeUpdate();
		}
		catch (ClassNotFoundException | SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
		}
		finally
		{
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		if (updateResult > 0) {
			return true;
		}
		return false;
	} // End of removeBrand() method

}