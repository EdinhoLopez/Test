package javaDAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javaDatabase.MariaDBConnection;
import javaModels.chef;

public class chefDAO {
	
	//Connection and statement that will be used in each method

		Connection con = null;

		Statement stm = null;

		//Determines whether a connection to the DB is possible		

		public Connection testConnection() {

					

			//Creates object from MariaDBConnection so you can use its getConnection Method

			MariaDBConnection mariadbConnection = new MariaDBConnection();

					

			try {
			//Variable "con" is assigned a connection to the Database

				con = mariadbConnection.getConnection();

				System.out.println("Connected!!!!!");

				return con;

			}

			catch(Exception e) {

			System.out.println("Connection failed to MariaDb");

				return null;

						

			}

			finally {

						

				if(con!=null) {

							

					try {

						con.close();

					} catch (SQLException e) {

						// TODO Auto-generated catch block

						e.printStackTrace();

					}
							
				}
		
			}

		}

		//Returns an ArrayList filled with Brands objects from database(Retrieve method)

		public ArrayList<chef> getAllChef() throws SQLException {

			// Declare variables

			Connection conn = null;

			Statement stmt = null;

			ResultSet rs = null;

			chef u = null;

			ArrayList<chef> brandList = null;



			// Assign query string to a variable

			String qString = "select * from chef";



			// Create MySqlConnection class instance

			MariaDBConnection mysql = new MariaDBConnection();



			// Begin try/catch block to query the database

			try

			{

				// Connect to database

				conn = mysql.getConnection();

				// If the connection fails the application won't make it to this point

				

				// Create Statement instance/object

				stmt = conn.createStatement();

			
				// Run query and assign to the ResultSet instance

				rs = stmt.executeQuery(qString);

				//Create list to hold Brands objects

				brandList = new ArrayList<chef>();

				// Read the ResultSet instance

				while (rs.next()) {

					// Each iteration creates a new Brand

					u = new chef();

					// Assign columns/fields to related fields in the Brand object

					// 1,2 and 3 represent column numbers/positions

					u.setChefID(rs.getInt(1));

					u.setChefName(rs.getString(2));

					// Add the Brand to the list

					brandList.add(u);

					// Repeat until rs.next() returns false (i.e., end of ResultSet)

				}

			}

			catch (ClassNotFoundException | IOException | SQLException e)

			{

				System.out.println("Error: " + e.getMessage());

				e.getStackTrace();

			}

			finally

			{

				if (rs != null) {

					rs.close();

				}

				if (stmt != null) {

					stmt.close();

				}

				if (conn != null) {

					conn.close();

				}

			}

			return brandList;

		} // End of getAllBrands method	
	
}
