package javaDAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javaDatabase.MariaDBConnection;
import javaModels.food;


public class foodDAO {
	
	//Returns an ArrayList filled with Brands objects from database(Retrieve method)

			public ArrayList<food> getAllFood() throws SQLException {

				// Declare variables

				Connection conn = null;

				Statement stmt = null;

				ResultSet rs = null;

				food u = null;

				ArrayList<food> brandList = null;



				// Assign query string to a variable

				String qString = "select * from food";



				// Create MySqlConnection class instance

				MariaDBConnection mysql = new MariaDBConnection();



				// Begin try/catch block to query the database

				try

				{

					// Connect to database

					conn = mysql.getConnection();

					// If the connection fails the application won't make it to this point

					

					// Create Statement instance/object

					stmt = conn.createStatement();

				
					// Run query and assign to the ResultSet instance

					rs = stmt.executeQuery(qString);

					//Create list to hold Brands objects

					brandList = new ArrayList<food>();

					// Read the ResultSet instance

					while (rs.next()) {

						// Each iteration creates a new Brand

						u = new food();

						// Assign columns/fields to related fields in the Brand object

						// 1,2 and 3 represent column numbers/positions

						u.setFoodID(rs.getInt(1));

						u.setFoodName(rs.getString(2));
						
						u.setPrice(rs.getDouble(3));
						
						u.setRegionID(rs.getInt(4));
						
						u.setChefID(rs.getInt(5));

						// Add the Brand to the list

						brandList.add(u);

						// Repeat until rs.next() returns false (i.e., end of ResultSet)

					}

				}

				catch (ClassNotFoundException | IOException | SQLException e)

				{

					System.out.println("Error: " + e.getMessage());

					e.getStackTrace();

				}

				finally

				{

					if (rs != null) {

						rs.close();

					}

					if (stmt != null) {

						stmt.close();

					}

					if (conn != null) {

						conn.close();

					}

				}

				return brandList;

			} // End of getAllBrands method	
	
}
