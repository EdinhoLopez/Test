package javaModels;

public class chef {
	
	private Integer chefID;
	
	private String chefName;
	
	public chef() {
		
	}

	public chef(Integer chefID, String chefName) {
		super();
		this.chefID = chefID;
		this.chefName = chefName;
	}

	public Integer getChefID() {
		return chefID;
	}

	public void setChefID(Integer chefID) {
		this.chefID = chefID;
	}

	public String getChefName() {
		return chefName;
	}

	public void setChefName(String chefName) {
		this.chefName = chefName;
	}
	
	
	

}
