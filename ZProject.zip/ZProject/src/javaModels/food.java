package javaModels;

public class food {

private String foodName;
	
	private Integer foodID;
	
	private Double price;
	
	private Integer regionID;
	
	private Integer chefID;
	
	public food() {
		
	}

	public food(String foodName, Integer foodID, Double price, Integer regionID, Integer chefID) {
		super();
		this.foodName = foodName;
		this.foodID = foodID;
		this.price = price;
		this.regionID = regionID;
		this.chefID = chefID;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public Integer getFoodID() {
		return foodID;
	}

	public void setFoodID(Integer foodID) {
		this.foodID = foodID;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Integer getRegionID() {
		return regionID;
	}

	public void setRegionID(Integer regionID) {
		this.regionID = regionID;
	}

	public Integer getChefID() {
		return chefID;
	}

	public void setChefID(Integer chefID) {
		this.chefID = chefID;
	}
	
}
