package javaModels;

public class region {
	
	private Integer regionID;
	
	private String regionName;
	
	public region() {
		
	}

	public region(Integer regionID, String regionName) {
		super();
		this.regionID = regionID;
		this.regionName = regionName;
	}

	public Integer getRegionID() {
		return regionID;
	}

	public void setRegionID(Integer regionID) {
		this.regionID = regionID;
	}

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
	
	

}
